function show(){
	alert("자바스크립트 실행됨.");
}